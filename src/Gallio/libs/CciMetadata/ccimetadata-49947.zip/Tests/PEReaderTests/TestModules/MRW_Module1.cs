namespace Module1 {
  public class Foo {
    public class Nested {
    }
    public Foo Bar() {
      return new Foo();
    }
  }
}
