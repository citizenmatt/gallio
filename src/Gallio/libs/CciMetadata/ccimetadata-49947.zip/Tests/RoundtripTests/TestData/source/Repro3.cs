﻿public class Repro3 {

    public Repro3(int a) {}

    public void Foo(int a) { }
    public void Foo() { }
}

public class Repro3v2 {

    public Repro3v2(int a) { }

    public void Foo(int a) { }
    public void Foo() { }
}
